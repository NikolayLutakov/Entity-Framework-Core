﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        //public static string ConnectionString = @"Server=.;Database=SoftJail;Trusted_Connection=True";
        public static string ConnectionString =
            @"Server=192.168.0.105,1433;Database=SoftJail;User ID=nlyutakov;Password=A123456a";
    }
}
